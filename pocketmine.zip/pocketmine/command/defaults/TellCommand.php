<?phpnamespace pocketmine\command\defaults;
use pocketmine\command\CommandSender;
use pocketmine\Player;
class TellCommand extends VanillaCommand{
public function __construct($name){
parent::__construct($name,"%pocketmine.command.tell.description","%commands.message.usage",["w", "msg", "m"]);
$this->setPermission("pocketmine.command.tell");}
public function execute(CommandSender $sender, $currentAlias, array $args){
if(!$this->testPermission($sender)){
return true;}
if(count($args) < 2){
$sender->sendMessage("§8[§dP§bW§8]:§7 Usage:§b /w <player> <message>");
$sender->sendMessage($this->ccinfo());
return false;}
$name = strtolower(array_shift($args));
$player = $sender->getServer()->getPlayer($name);
if($player === $sender){
$sender->sendMessage("§8[§dP§bW§8]:§7 You§b cannot §7send message to §byourself!");
return true;}
if($player === null){return $sender->sendMessage("§8[§dP§bW§8]:§7 This player is§b offline§7 or you entered an §bwrong§7 name!");}
$sender->getServer()->getLogger()->info("<".$sender->getName()." »> " . $player->getName() . "> " . strtolower(implode(" ", $args)));
if($player instanceof Player){
$sender->sendMessage("§8[§dChit§bChat§8]:§f §7<You §8»>§7 " . $player->getName() . "§7> ".$this->color().strtolower(implode(" ", $args)));
$sender->sendMessage($this->ccinfo());
$player->sendMessage("§8[§dChit§bChat§8]:§7 <" . ($sender instanceof Player ? $sender->getName() : $sender->getName()) . " §8»> §7".$player->getName()."> ".$this->color().strtolower(implode(" ", $args)));
foreach($sender->getServer()->getOnlinePlayers() as $onlinep){
if($onlinep->hasPermission("see.pchat")){$onlinep->sendMessage("§7<".$sender->getName()." §8»>§7 " . $player->getName() . "> " . strtolower(implode(" ", $args)));}}}else{
$sender->sendMessage("§7»§f Player is§c offline§f or you entered an §ewrong§f name!");}
return true;}
private function color(){
switch(rand(1,5)){
case 1:
return "§b";
break;
case 2:
return "§d";
break;
case 3:
return "§e";
break;
case 4:
return "§a";
break;
case 5:
return "§6";
break;
}}
private function ccinfo(){
switch(rand(1,2)){
case 1:
return "§7New here?\nUse command:§b /help§7 to learn somethings useful about §bserver!";break;
case 2:
return "§7Having problems? let's contact!\n§7Discord: §bdiscord.gg/pwix";break;}}}
